//
//  MHDeviceGroupManager.h
//  MiHome
//
//  Created by Wayne Qiao on 15/12/3.
//  Copyright © 2015年 小米移动软件. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHDataGroupableDeviceConfig.h"
#import "MHDeviceGroupStatusConfigData.h"

@class MHCreateDeviceGroupResponse;
@class MHModifyDeviceGroupResponse;
@class MHGetGroupableDeviceResponse;
@class MHCheckDeviceGroupStatusResponse;

@interface MHDeviceGroupManager : NSObject

+ (instancetype)sharedInstance;

#pragma mark - new device group request
/* 创建设备组 */
- (void)createDeviceGroupWithName:(NSString *)groupName
                       deviceDids:(NSArray *)deviceDids
                          succeed:(void(^)(MHCreateDeviceGroupResponse *response))succeed
                           failed:(void(^)(NSError *error))failed;

/* 修改设备组，可同时支持加删，操作为先加后删，请保证两个list中没有重复did */
- (void)modifyDeviceGroupWithGroupDid:(NSString *)groupDid
                        addDeviceDids:(NSArray *)addDeviceDids
                     removeDeviceDids:(NSArray *)removeDeviceDids
                              succeed:(void(^)(MHModifyDeviceGroupResponse *response))succeed
                               failed:(void(^)(NSError *error))failed;

/* 获取支持分组的设备Model */
- (void)getGroupableDeviceModelsSucceed:(void(^)(MHGetGroupableDeviceResponse *response))succeed
                                 failed:(void(^)(NSError *error))failed;


/* 检查设备组的状态 */
- (void)checkDeviceGroupStatusWithGroupDids:(NSArray *)groupDids
                                    succeed:(void(^)(MHCheckDeviceGroupStatusResponse *response))succeed
                                     failed:(void(^)(NSError *error))failed;

@end
