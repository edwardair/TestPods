//
//  MHDeviceBluetoothXiaoMiSecureBindRequest.h
//  MiHomeKit
//
//  Created by 彭勇 on 2017/7/31.
//  Copyright © 2017年 小米移动软件. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHDeviceBluetoothXiaoMiSecureBindRequest : MHBaseRequest
@property (nonatomic, copy) NSString *mac;
@property (nonatomic, copy) NSString *model;
@property (nonatomic, copy) NSString *ltmk;
@property (nonatomic, copy) NSString *token;
@property (nonatomic, copy) NSString *deviceCert;
@property (nonatomic, copy) NSString *manuCert;
@end
