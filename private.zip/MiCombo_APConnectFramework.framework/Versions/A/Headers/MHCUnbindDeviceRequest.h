//
//  MHCUnbindDeviceRequest.h
//  MiNetworkFramework
//
//  Created by huchundong on 2017/9/28.
//  Copyright © 2017年 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHMiotBaseRequest.h"

@interface MHCUnbindDeviceRequest : MHMiotBaseRequest
@property(nonatomic, strong)NSString*       did;
@end
