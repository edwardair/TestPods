//
//  MHDeviceGroupFUInfoRequest.h
//  MiHome
//
//  Created by zhangxu on 2018/10/24.
//  Copyright © 2018年 小米移动软件. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHDeviceGroupFUInfoRequest : MHBaseRequest

@property (nonatomic, strong) NSArray *dids;

@end

