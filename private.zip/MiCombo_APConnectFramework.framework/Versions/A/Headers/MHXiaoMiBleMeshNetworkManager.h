//
//  MHXiaoMiBleMeshNetworkManager.h
//  MiHomeKit
//
//  Created by 彭勇 on 2018/4/18.
//
#import <MiHomeFoundation/MHSafeDictionary.h>

typedef NS_ENUM(NSInteger, reportResutType){
    reportResutTypeSuccess = 0,
    reportResutTypeProvisionFail,
    reportResutTypeMeshConfigFail,
};

@interface MHXiaoMiBleMeshNetworkManager : NSObject

+ (void)authServerWithPid:(NSInteger)pid
                   pubKey:(NSString *)pub
               deviceInfo:(NSString *)devInfo
               manuCertId:(NSString *)manuCertId
                  devCert:(NSString *)devCert
                 pairCode:(NSString *)code
                 callback:(void(^)(BOOL suc, MHSafeDictionary *result,NSError *error))block;

+ (void)bindServerWithPid:(NSInteger)pid
                      mac:(NSString *)mac
                      did:(NSString *)did
                     sign:(NSString *)sign
                    token:(NSString *)token
                 callback:(void(^)(BOOL suc, MHSafeDictionary *result,NSError *error))block;

+ (void)ctlInfoWithCallback:(void(^)(BOOL suc, MHSafeDictionary *result,NSError *error))block;

+ (void)deviceModelListWithPid:(NSInteger)pid callback:(void(^)(BOOL suc, NSArray *models,NSError *error))block;

+ (void)reportResultWithDid:(NSString *)did
                       auth:(NSString *)auth
                  deviceKey:(NSString *)key
                 resultType:(reportResutType)type
                 callback:(void(^)(BOOL suc,NSError *error))block;

+ (void)deviceInfoWithDid:(NSString *)did
                 callback:(void(^)(BOOL suc, MHSafeDictionary *result,NSError *error))block;
@end
