//
//  MiotSpecAction.h
//  AFNetworking
//
//  Created by pencilCool on 2019/5/10.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/**
 用来表示设备支持的action
 */
@class MiotSpecService;
@interface MiotSpecAction : NSObject <NSCoding>
@property (nonatomic, assign) NSInteger aiid;        //实例ID （iid）
@property (nonatomic, assign) NSInteger siid;
@property (nonatomic, copy) NSString *serviceType;  //当前Action所在service
@property (nonatomic, copy) NSString *type;         //action type
@property (nonatomic, copy) NSString *actionDes;    //action description (description)
@property (nonatomic, strong) NSArray *inParam;     //(in)
@property (nonatomic, strong) NSArray *outParam;    //(out)
@property (nonatomic, weak) MiotSpecService *service;

@end

NS_ASSUME_NONNULL_END
