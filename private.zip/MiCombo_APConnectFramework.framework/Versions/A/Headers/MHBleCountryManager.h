//
//  MHCountryManager.h
//  MiHome
//
//  Created by Woody on 16/1/20.
//  Copyright © 2016年 小米移动软件. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHCountryManagerProtocol.h"

@interface MHBleCountryManager : NSObject<MHCountryManagerProtocol>

- (void)setServerCode:(NSString*) serverCode isChina:(BOOL)isChina;
- (BOOL)isInChinaNow;
- (NSString*)curServerCode;

@end
