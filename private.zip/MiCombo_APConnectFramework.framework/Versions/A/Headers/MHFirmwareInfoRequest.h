//
//  MHFirmwareInfoRequest.h
//  MiNetworkFramework
//
//  Created by Shujun on 2017/7/17.
//  Copyright © 2017年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHFirmwareInfoRequest : MHBaseRequest
- (instancetype)initWithDeviceModel:(NSString *)model;
@end
