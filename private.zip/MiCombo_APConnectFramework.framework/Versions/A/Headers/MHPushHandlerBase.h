//
//  MHPushHandlerBase.h
//  MiHomeKit
//
//  Created by wayne on 14/11/28.
//  Copyright (c) 2014年 小米移动软件. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface MHPushHandlerBase : NSObject

/**
 *  生成PushHandler
 *
 *  @param pushType 本PushHandler能够处理的push类型
 *
 *  @return PushHandler
 */
- (instancetype)initWithPushType:(NSString *)pushType;

/**
 *  根据Push消息中的参数响应Push
 *
 *  @param params Push消息中的参数，最后一个参数表示收到Push消息时app是否在前台
 *
 *  @discussion 针对不同类型的push消息，参数的处理也不尽相同，需要子类来实现针对不同push消息的处理
 *
 *  @return YES:push已被处理，NO:push未被处理
 */
- (BOOL)handlePushWithParams:(NSArray *)params;

// 通过消息列表过来的请求
-  (BOOL)handlePushWithParamsDict:(NSDictionary *)params;
// if current view display alertView, dimiss alert
- (void)showAlertWithclickButtonIndex:(void(^)(UIAlertView *alertView, NSInteger clickIndex))clickButtonIndex
                                title:(NSString *)title
                              message:(NSString *)message
                    cancelButtonTitle:(NSString *)cancelButtonTitle
                    otherButtonTitles:(NSString *)otherButtonTitles, ...NS_REQUIRES_NIL_TERMINATION;

- (void)updateAlertWithclickButtonIndex:(void(^)(UIAlertView *alertView, NSInteger clickIndex))clickButtonIndex
                                dismiss:(BOOL)dismiss
                                title:(NSString *)title
                              message:(NSString *)message
                    cancelButtonTitle:(NSString *)cancelButtonTitle
                    otherButtonTitles:(NSString *)otherButtonTitles, ...NS_REQUIRES_NIL_TERMINATION;

- (BOOL)isNeedLogin;

@property (nonatomic, readonly) NSString* pushType;

@end
