//
//  MHBindDeviceRequest.h
//  MiDeviceFramework
//
//  Created by zhangyinze on 16/8/31.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//
#import "MHBaseRequest.h"
@interface MHBindDeviceRequest : MHBaseRequest

@property (nonatomic, copy, readonly) NSString *did;
@property (nonatomic, copy, readonly) NSString *token;

-(instancetype)initWithDid:(NSString*)did andToken:(NSString*)token;

@end
