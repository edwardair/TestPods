//
//  MiotGetDevPropertyRequest.h
//  MiNetworkFramework
//
//  Created by CoolKernel on 05/07/2017.
//  Copyright © 2018 小米移动软件. All rights reserved.
//

#import "MiotSpecBaseRequest.h"
@interface MiotSpecGetPropertyRequest : MiotSpecBaseRequest
@property (nonatomic, strong) NSArray *pids;

@end
