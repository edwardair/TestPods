//
//  MHDeviceGroupFUInfo.h
//  MiHome
//
//  Created by zhangxu on 2018/10/24.
//  Copyright © 2018年 小米移动软件. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MHDeviceGroupFUInfo : NSObject

@property (nonatomic, copy) NSString *did;
@property (nonatomic, copy) NSString *currentVersion;
@property (nonatomic, copy) NSString *latestVersion;
@property (nonatomic, copy) NSString *changeLog;
@property (nonatomic, copy) NSString *safeUrl;
@property (nonatomic, copy) NSString *uploadTime;
@property (nonatomic, copy) NSString *url;
@property (nonatomic, copy) NSString *md5;
@property (nonatomic, assign) BOOL isLatest;

@end

NS_ASSUME_NONNULL_END
