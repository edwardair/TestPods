//
//  MiotNetworkingIMP.h
//  MiCombo_APConnectFramework
//
//  Created by pencilCool on 2019/4/26.
//

#import <Foundation/Foundation.h>
#import "MiotSpecNetworkProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface MiotSpecNetworkingIMP : NSObject<MiotSpecNetworkProtocol>
+ (instancetype)shared;

#pragma mark - MiotSpecNetworkProtocol
- (void)RequestCommonURL:(NSString *)url
                method:(NSInteger)method 
                params:(NSDictionary *)params
               success:(void(^)(id))success
               failure:(void(^)(NSError*))failure;

- (void)sendRequest:(id)request
             method:(MiotSpecNetworkMethod)method
            success:(void (^)(id))success
            failure:(void (^)(NSError *))failure;


@end

NS_ASSUME_NONNULL_END
