//
//  MHBindDidRequest.h
//  MiBluetoothFramework
//
//  Created by yinze zhang on 2016/9/28.
//  Copyright © 2016年 yinze zhang. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHBindDidRequest : MHBaseRequest

-(instancetype)initWithDid:(NSString*)did andToken:(NSData*)loginToken andBeaconKey:(NSData*)beaconKey;

@end
