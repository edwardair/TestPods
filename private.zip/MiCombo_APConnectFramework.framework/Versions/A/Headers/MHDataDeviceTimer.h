//
//  MHDataDeviceTimer.h
//  MiHomeSDK
//
//  Created by Wayne Qiao on 16/5/13.
//  Copyright © 2016年 xiaomi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHCrontabTime.h"

@interface MHDataDeviceTimer : NSObject

+ (instancetype)dataWithJSONObject:(id)json;
- (NSDictionary *)jsonObject __deprecated_msg("存在历史遗留逻辑，适配旧的一些设备，定时参数参数会被篡改，建议使用jsonObjectNormal");
- (NSDictionary *)jsonObjectNormal;

// 建议设置为YES
// 为了兼容旧逻辑，默认是NO。
@property (nonatomic, assign) BOOL isUserNewParamStruct;

@property (nonatomic, strong) MHCrontabTime* onTimer;   //开启时间
@property (nonatomic, copy)   NSString* onMethod;
// 如果onParam 您传的参数是NSString 请联系米家开发者，在github issue 上反馈。
@property (nonatomic, retain) NSArray*  onParam;
@property (nonatomic, copy)   NSString* onDesc;         //开启描述
@property (nonatomic, assign) BOOL isOnOpen;            //“开启时间”是否打开

@property (nonatomic, strong) MHCrontabTime* offTimer;  //关闭时间
@property (nonatomic, copy)   NSString* offMethod;
// 如果offParam您传的参数是NSString 请联系米家开发者，在github issue 上反馈。
@property (nonatomic, retain) NSArray*  offParam;
@property (nonatomic, copy)   NSString* offDesc;        //关闭描述
@property (nonatomic, assign) BOOL isOffOpen;           //“关闭时间”是否打开
@property (nonatomic, assign) BOOL isEnabled;           //定时器是否打开

@property (nonatomic, assign) NSInteger timerId;
@property (nonatomic, retain) NSString* name;
@property (nonatomic, retain) NSString* identify;
@property (nonatomic, retain) NSString* did;
@property (nonatomic, retain) NSArray* authed;
@property (nonatomic, assign) NSInteger status;  //用于处理定时数据是否同步成功

@end
