//
//  MHDeviceBindWithBindkeyResponse.h
//  MiNetworkFramework
//
//  Created by huchundong on 2018/3/7.
//  Copyright © 2018年 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MHDeviceBindWithBindkeyResponse : NSObject
/**
  0 ：ok
 -1 ：bind_key非法
 -2 ：bing_key过期
 -3 ：bind_key已经绑定且不是请求的用户
 -4 ：绑定失败
 -5 ：未知服务器错误
 */
@property(nonatomic, assign)NSInteger   ret;

@property(nonatomic, strong)NSString*   did;

@property(nonatomic, assign)NSInteger   code;
@end
