//
//  MHFetchDevicesRequest.h
//  MSmartHomeFramework
//
//  Created by zhangyinze on 16/8/19.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHFetchDevicesRequest : MHBaseRequest

@property (nonatomic, strong, readonly) NSArray<NSString*> *dids;


-(instancetype)initWithDids:(NSArray<NSString*>*)dids;

@end
