//
//  MiotSpecDeviceSummary.h
//  AFNetworking
//
//  Created by pencilCool on 2019/5/7.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


/**
 
 从 https://api.home.mi.com/api/v1/devices 这个接口
 获取的spec设备列表，只有设备的部分信息。
 
 ```
 {
 category = camera;
 "cloud_id" = 10;
 "common_mark" = 0;
 did = M1GAxtaxxxxxxxUGAg5Nzk5MzU0NhXaCgA;
 "is_shared" = 0;
 "last_update_timestamp" = 1556260766375322;
 mac = "7C:49:EB:AA:D2:96";
 name = "Mi Home Security Camera Basic 1080P   ";
 online = 0;
 "real_did" = 97993546;
 rid = 0;
 type = "urn:miot-spec-v2:device:camera:0000A01C:mijia-v3:1";
 }
 ```
 
 并不包含完整的service 还有property 等信息。我们把这些信息用
 ` MiotSpecDeviceSummary` 来标识。
 
 要想获得device 的service 和 property 等信息。需要根据devType 通过
 http://miot-spec.org/miot-spec-v2/instance这个接口来获取
 */

@interface MiotSpecDeviceSummary : NSObject
@property (nonatomic, copy) NSString *pdid;//服务器选择性分发
@property (nonatomic, copy) NSString *did;
@property (nonatomic, assign) BOOL online;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *category;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *rid;
@property (nonatomic, assign) BOOL isShared;
@property (nonatomic, copy) NSString *cloudID;
@property (nonatomic, copy) NSString *realID;
@property (nonatomic, copy) NSString *mac;
@end

NS_ASSUME_NONNULL_END
