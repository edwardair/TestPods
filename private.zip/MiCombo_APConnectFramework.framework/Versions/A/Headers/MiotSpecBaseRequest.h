//
//  MiotSpecBaseRequest.h
//  MiHome
//
//  Created by coolkernel on 2018/8/17.
//  Copyright © 2018 小米移动软件. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 spec 网络请求的基类：
 域名用的是：
 https://api.home.mi.com";
 */
@interface MiotSpecBaseRequest : NSObject

+ (void)setupBaseRequestUrl:(NSString *)url;

- (NSString *)api;

- (NSString *)absoluteURL;

- (NSDictionary *)headParameters;

- (NSDictionary *)requestParameters;

@end
