//
//  MHAccountProfile.h
//  MSmartHomeFramework
//
//  Created by zhangyinze on 16/8/12.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface MiioBluetoothUtils : NSObject

@property (atomic, strong) CBCentralManager *centralManager;

+ (instancetype)sharedInstance;

- (void)openCentralManager;

- (BOOL)isBluetoothOn;

- (void)registerCentralManagerDelegate:(id<CBCentralManagerDelegate>)delegate;
- (void)unRegisterCentralManagerDelegate:(id<CBCentralManagerDelegate>)delegate;

- (void)registerPeripheral:(CBPeripheral *)peripheral delegate:(id<CBPeripheralDelegate>)delegate;
- (void)unRegisterPeripheral:(CBPeripheral *)peripheral delegate:(id<CBPeripheralDelegate>)delegate;

@end
