//
//  MHSharedDeviceRequest.h
//  MiDeviceFramework
//
//  Created by yinze zhang on 2016/11/3.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHSharedDeviceRequest : MHBaseRequest

-(instancetype)initWithUserId:(NSString*)userId;

@end
