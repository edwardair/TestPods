//
//  MiotSpecDevice.h
//  MiHome
//
//  Created by coolkernel on 2018/8/5.
//  Copyright © 2018 小米移动软件. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MiotSpecProperty.h"

/**
 用来表示查询spec之后，解析处理的到的device
 */

@interface MiotSpecDevice : NSObject <NSCoding>
@property (nonatomic, copy) NSString *deviceDes;    //设备描述 (description)
@property (nonatomic, copy) NSString *type;
@property (nonatomic, strong) NSArray <MiotSpecService *> *services;
@property (nonatomic, copy) NSString *did;      //设备id
@property (nonatomic, copy) NSString *realID;     
@property (nonatomic, copy) NSString *name;     //设备名称

/**
 一个特定类型的设备有多种sid
 */
- (MiotSpecService *)getServiceFromSid:(NSInteger)sid;
+ (NSString *)getDeviceInstanceProflieCategory:(NSString *)type;
+ (NSString *)getDeviceInstanceProfileVersion:(NSString *)type;

+ (instancetype)specModelWithJSON:(id)json;

@end
