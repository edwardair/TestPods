//
//  MHDeviceGroupFirmwareUpdateManager.h
//  MiHomeDeviceUI
//
//  Created by zhangxu on 2018/8/22.
//

#import <Foundation/Foundation.h>
//#import "MHCheckDeviceGroupStatusResponse.h"
//#import <MiHomeKit/MHDeviceBluetoothXiaoMi.h>
//#import "MHLampGroupFirmwareUpdateData.h"
#import "MHDeviceGroupFUInfo.h"

@interface MHDeviceGroupFirmwareUpdateManager : NSObject

+ (instancetype)sharedInstance;
- (NSString *)versionForLatestFirmware;
- (NSString *)pathForLatestFirmware;
- (NSString *)changeLogForLatestFirmware;
- (void)checkoutFirmwareUpdateWithDids:(NSArray *)dids succeed:(void(^)(NSArray<MHDeviceGroupFUInfo *> *infos))succeed failed:(void(^)(NSError *error))failed;

@end
