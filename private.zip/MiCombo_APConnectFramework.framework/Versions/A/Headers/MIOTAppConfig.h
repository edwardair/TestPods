//
//  MIOTAppConfig.h
//  AFNetworking
//
//  Created by pencilCool on 2019/8/2.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 normal means: sdk  can only access devices of special device manufacturer
 */
typedef NS_ENUM(NSUInteger,MIOTSDKType) {
    MIOTSDKType_Normal,
    MIOTSDKType_ChinaMobile,
    MIOTSDKType_ChinaUnicom,
    MIOTSDKType_ChinaTeleCom
};


typedef NS_ENUM(NSUInteger,MIOTSDKStatus) {
    MIOTSDKStatus_Realse,
    MIOTSDKStatus_Debug
};


@interface MIOTAppConfig : NSObject

/**
 default type is MIOTSDKType_Normal
 */
+ (MIOTSDKType)sdkType;
+ (void)setSDKType:(MIOTSDKType)type;
+ (BOOL)isNormalSDK;

+ (MIOTSDKStatus)sdkStatus;
+ (void)setSDKStatus:(MIOTSDKStatus)status;
+ (BOOL)isDebugStatus;
@end

NS_ASSUME_NONNULL_END
