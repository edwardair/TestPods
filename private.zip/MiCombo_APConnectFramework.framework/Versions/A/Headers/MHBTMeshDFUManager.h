//
//  MHBTMeshDFUManager.h
//  MHMeshOTA
//
//  Created by Shujun on 2018/5/31.
//  Copyright © 2018年 xiaomi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHBaseRequest.h"

typedef NS_ENUM(NSInteger, MHBTMeshDFUCommandType) {
    MHBTMeshDFUCommandReadProtocolVersion = 1,  //版本查询 命令
    MHBTMeshDFUCommandReadFragmentSize,         //FragmentSize查询 命令
    MHBTMeshDFUCommandReadLastFragmentIndex,    //断点查询 命令
    MHBTMeshDFUCommandSetDelaytoSwitchFirmware  //设置新固件版本切换的定时 命令
};

typedef NS_ENUM(NSInteger, MHBTMeshDFUCommandError) {
    MHBTMeshDFUUnknownCommand = 1,
    MHBTMeshDFUAuthenticationFailure,
    MHBTMeshDFUInvalidParameters,
    MHBTMeshDFUMemoryCapacityExceeded,
    MHBTMeshDFUDeviceBusy,
    MHBTMeshDFUUnspecifiedError
};

@interface MHBtMeshDFUCommandResponse : NSObject
@property (nonatomic, assign) MHBTMeshDFUCommandType type;
@property (nonatomic, assign) MHBTMeshDFUCommandError errorCode;
@property (nonatomic, assign) NSInteger int_value;
@property (nonatomic, strong) id value;
@end

@interface MHBtMeshDFUMsgRequest : MHBaseRequest
@property (nonatomic, copy) NSString *did;
@end

@interface MHBtMeshDevInfoRequest : MHBaseRequest
@property (nonatomic, copy) NSString *did;
@property (nonatomic, copy) NSString *version;
@end

@interface MHBtMeshDFUMsgRsp : NSObject
@property (nonatomic, copy) NSString *changeLog;
@property (nonatomic, copy) NSString *url;
@property (nonatomic, copy) NSString *md5;
@property (nonatomic, copy) NSString *version;
@end


///  used by `MHBTMeshDFUProcessor`
@interface MHBTMeshDFUManager : NSObject
+ (instancetype)shareInstance;

/**
 生成command。command类型参考MHBTMeshDFUCommandType枚举

 @param commandType 命令类型
 @param parameters 额外参数 设置固件切换时间时需要传具体的时间
 @return data
 */
- (NSData *)commandWithType:(MHBTMeshDFUCommandType)commandType
                 parameters:(NSData *)parameters;


/**
 解析发送命令后设备回给app的信息

 @param data 设备返回的event信息
 @return rsp数据
 */
- (MHBtMeshDFUCommandResponse *)meshDFUCommandRspWithData:(NSData *)data;


/**
 获取固件升级信息

 @param did 设备did
 @param success 回调返回一个数据结构 包括log version url 和 MD5
 */
- (void)requestMeshDFUMsgWithDid:(NSString *)did
                         success:(void(^)(MHBtMeshDFUMsgRsp *rsp))success
                         failure:(void(^)(void))failure;


/**
 向服务端上传设备的固件版本信息

 @param did 设备did
 @param version 设备当前的固件版本
 */
- (void)uploadMeshDevInfoWithDid:(NSString *)did
                         version:(NSString *)version
                         success:(void(^)(void))success
                         failure:(void(^)(void))failure;


/**
 下载bin文件，下载前会检查lruCache。

 @param model 设备model
 @param version 固件version
 @param url 下载url
 @param progress NSProgress 如果UI想处理进度 自己KVO监听progress
 @param success 返回文件路径
 */
- (void)downloadFirmwareWithModel:(NSString *)model
                          version:(NSString *)version
                              url:(NSString *)url
                         progress:(NSProgress *)progress
                          success:(void(^)(NSString *path))success
                          failure:(void(^)(NSError *error))failure;


/**
 是否需要更新
 判断当前版本号是否比最新版本号小

 @param currentVersion 固件当前版本号
 @param latestVersion 固件最新的版本号
 */
- (BOOL)needUpdateWithCurrentVersion:(NSString *)currentVersion
                       latestVersion:(NSString *)latestVersion;
@end
