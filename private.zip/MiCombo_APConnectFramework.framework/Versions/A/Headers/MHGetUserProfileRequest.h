//
//  MHGetUserProfileRequest.h
//  MiNetworkFramework
//
//  Created by huchundong on 2017/7/6.
//  Copyright © 2017年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHGetUserProfileRequest : MHBaseRequest
@property (nonatomic, strong)NSString *uid;
@end
