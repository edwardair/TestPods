//
//  MHFetchNewDevicesRequest.h
//  MSmartHomeFramework
//
//  Created by zhangyinze on 16/8/19.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//
#import "MHBaseRequest.h"

@interface MHFetchNewDevicesRequest : MHBaseRequest

@property (nonatomic, copy, readonly) NSString *ssid;
@property (nonatomic, copy, readonly) NSString *bssid;
@property (nonatomic, copy, readonly) NSString *deviceMac;

-(instancetype)initWithSSID:(NSString*)ssid withBSSID:(NSString*)bssid withDeviceMac:(NSString*)deviceMac withChannel:(NSString*)channel;

@end
