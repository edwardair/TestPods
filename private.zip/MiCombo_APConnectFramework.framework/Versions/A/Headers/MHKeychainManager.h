//
//  MHKeychainManager.h
//  MiNetworkFramework
//
//  Created by CoolKernel on 1/18/17.
//  Copyright © 2017 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MHKeychainManager : NSObject
+ (NSString *)getAccesstoken;
+ (NSString *)getClientId;

+ (void)setAccesstoken:(NSString *)token;
+ (void)setClientid:(NSString *)clientid;

+ (void)setExtToken:(NSString*)extToken;
+ (NSString*)getExtToken;
+ (void)setExtTokenExpire:(NSNumber*)number;
+ (NSNumber*)getExtTokenExpire;

+ (void)setUserId:(NSString*)userId;
+ (NSString*)getUserId;
@end
