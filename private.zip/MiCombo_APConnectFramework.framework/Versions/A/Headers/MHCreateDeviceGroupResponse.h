//
//  MHCreateDeviceGroupResponse.h
//  MiHomeDeviceUI
//
//  Created by zhangxu on 2018/8/22.
//

#import <Foundation/Foundation.h>

@interface MHCreateDeviceGroupResponse : NSObject
@property (nonatomic, assign) NSInteger code;
@property (nonatomic, copy  ) NSString *message;
@property (nonatomic, assign) BOOL needAlterDevice;
@property (nonatomic, copy) NSString *groupDid;
@end
