//
//  MHXiaoMiBleMeshAuthServerRequest.h
//  MiHomeKit
//
//  Created by 彭勇 on 2018/4/18.
//

#import  "MHBaseRequest.h"

@interface MHXiaoMiBleMeshAuthServerRequest : MHBaseRequest
@property (nonatomic, assign) NSInteger pdid;
@property (nonatomic, copy) NSString *pub;
@property (nonatomic, copy) NSString *manu_cert_id;
@property (nonatomic, copy) NSString *dev_cert;
@property (nonatomic, copy) NSString *dev_info;
@property (nonatomic, copy) NSString *code;
@end
