//
//  MHDeviceCheckBindKeyRequest.h
//  Pods
//
//  Created by pencilCool on 2019/5/29.
//

#import <Foundation/Foundation.h>
#import "MHBaseRequest.h"
NS_ASSUME_NONNULL_BEGIN

@interface MHDeviceCheckBindKeyRequest : MHBaseRequest
@property (nonatomic, copy) NSString* bindKey;
@end

NS_ASSUME_NONNULL_END
