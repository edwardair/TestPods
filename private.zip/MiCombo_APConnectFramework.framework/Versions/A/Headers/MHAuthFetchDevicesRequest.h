//
//  MHAuthFetchDevicesRequest.h
//  MiNetworkFramework
//
//  Created by CoolKernel on 28/02/2017.
//  Copyright © 2017 zhangyinze. All rights reserved.
//

#import "MHAuthBaseRequest.h"

@interface MHAuthFetchDevicesRequest : MHAuthBaseRequest
@property (nonatomic, strong, readonly) NSArray<NSString*> *dids;


-(instancetype)initWithDids:(NSArray<NSString*>*)dids;
@end
