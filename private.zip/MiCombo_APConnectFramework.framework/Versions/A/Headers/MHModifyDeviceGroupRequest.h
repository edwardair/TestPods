//
//  MHModifyDeviceGroupRequest.h
//  MiHomeDeviceUI
//
//  Created by zhangxu on 2018/8/22.
//


#import "MHBaseRequest.h"

@interface MHModifyDeviceGroupRequest : MHBaseRequest

@property (nonatomic, copy)NSString *groupDid;
@property (nonatomic, strong) NSArray *addDeviceDids;
@property (nonatomic, strong) NSArray *removeDeviceDids;

@end
