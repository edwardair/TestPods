//
//  MHDeleteUsers.h
//  MiDeviceFramework
//
//  Created by yinze zhang on 2016/11/3.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHDeleteUser.h"

@interface MHDeleteUsers : NSObject

@property(nonatomic, strong) NSArray<MHDeleteUser*> *deleteUsers;

@end
