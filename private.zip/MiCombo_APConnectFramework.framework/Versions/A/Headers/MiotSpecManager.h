//
//  MiotSpecManager.h
//  MiHome
//
//  Created by coolkernel on 2018/8/6.
//  Copyright © 2018 小米移动软件. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MiotSpecNetworking.h"
#import "MiotSpecNetworkingIMP.h"


@protocol MiotSpecCacheProtocol <NSObject>
- (void)saveMiotDeviceInstanceProfile:(id)instanceData;
- (id)loadMiotDeviceInstanceProfile;
- (void)removeInstanceProfile;

- (void)saveMiotDeviceTypeMapper:(id)instanceData;
- (id)loadMiotDeviceTypeMapperCache;
- (void)removeDeviceTypeMapperCache;

@end

@class MiotSpecDevice, MiotSpecProperty, MiotSpecAction;
@interface MiotSpecManager : NSObject

+ (instancetype)shared;

- (void)registerMiotDeviceCacheDelegate:(id <MiotSpecCacheProtocol>)delegate;

/**
 如果不注册新的网络模块，默认使用MiotSpecNetworkingIMP 的实现
 */
- (void)registerMiotSpecNetworkingDelegate:(id <MiotSpecNetworkProtocol>)delegate;
///获取设备instance profile
- (MiotSpecDevice *)getCacheDeviceInstance:(NSString *)devType;

- (void)getDeviceInstanceWithDevType:(NSString *)devType
                          completion:(void (^)(MiotSpecDevice * device))completion;

/**
 获取指定device instance

 @param devType device type
 @param isCache 是否在内存中加载，默认加载，（如果本地没有，会从后台拉取出来后存在本地）
 @param completion result
 */
- (void)getDeviceInstanceWidthType:(NSString *)devType
                           isCache:(BOOL)isCache
                        completion:(void (^)(MiotSpecDevice * device))completion;



/**
 用户所有设备支持的miotspec type，model映射表

 @param completion result
 */
- (void)getUserAllSupportMiotspecMapper:(MiotCompletion)completion;

- (NSString *)deviceInstanceTypeFromModel:(NSString *)model;

- (NSDictionary *)deviceInstanceTypeFromModels:(NSArray *)models;

- (void)removeDeviceInstanceFile;

- (void)removeDeviceTypeMappingFile;

#ifdef APP_DEVELOPMENT
/**
 当前支持miotspec type，model的映射表

 @param type (0:released，1:preview，2:debug 注：目前只会针对released模式进行本地缓存)
 @param completion result
 */
- (void)getAllSupportMiotspecMapper:(NSInteger)type
                         completion:(void (^)(id))completion;

#endif
@end
