//
//  MiotSpecActionResponse.h
//  AFNetworking
//
//  Created by pencilCool on 2019/5/10.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface MiotSpecActionResponse: NSObject
@property (nonatomic, strong) NSString *aid;
@property (nonatomic, strong) NSString *oid;
@property (nonatomic, strong) NSArray *outParam;
@property (nonatomic, strong) NSString *des;
@end

NS_ASSUME_NONNULL_END
