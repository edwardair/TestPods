//
//  MiotSpecProperty.h
//  MiHome
//
//  Created by coolkernel on 2018/8/3.
//  Copyright © 2018 小米移动软件. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, MiotAccessType) {
    MiotAccessType_unkown,
    MiotAccessType_Read,
    MiotAccessType_Write,
    MiotAccessType_Notify,
    MiotAccessType_ReadWrite,
    MiotAccessType_All,
};

@interface MiotSpecPropertyAccess : NSObject <NSCoding>
@property (nonatomic, assign) MiotAccessType type;
@end

@interface MiotSpecValueRange : NSObject <NSCoding>
@property (nonatomic, assign) float minValue;
@property (nonatomic, assign) float maxValue;
@property (nonatomic, assign) float step;
@property (nonatomic, copy) NSString *format;

@end

@interface MiotSpecPropertyValue : NSObject <NSCoding>
@property (nonatomic, copy) NSString *valueDes;    //(description)
@property (nonatomic) id value;

@end

@class MiotSpecService;
@interface MiotSpecProperty : NSObject <NSCoding>
@property (nonatomic, assign) NSInteger piid;            //实例ID （iid）
@property (nonatomic, assign) NSInteger siid;
@property (nonatomic, copy) NSString *serviceType;      //当前property所在service
@property (nonatomic, copy) NSString *type;             //property type
@property (nonatomic, copy) NSString *propertyDes;      //property description (description)
@property (nonatomic, copy) NSString *format;           //数据类型 （ps. String）
@property (nonatomic, copy) NSString *unit;
@property (nonatomic, strong) MiotSpecPropertyAccess *valueAccess;       //读写权限声明
@property (nonatomic, strong) MiotSpecValueRange *valueRange;
@property (nonatomic, copy) NSArray <MiotSpecPropertyValue *> *valueList;       //(value-list)

@property (nonatomic, weak) MiotSpecService *service;

@end
