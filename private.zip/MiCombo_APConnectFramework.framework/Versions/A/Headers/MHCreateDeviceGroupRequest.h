//
//  MHCreateDeviceGroupRequest.h
//  MiHomeDeviceUI
//
//  Created by zhangxu on 2018/8/22.
//


#import "MHBaseRequest.h"

@interface MHCreateDeviceGroupRequest : MHBaseRequest

@property (nonatomic, copy) NSString *groupName;
@property (nonatomic, strong) NSArray *deviceDids;

@end
