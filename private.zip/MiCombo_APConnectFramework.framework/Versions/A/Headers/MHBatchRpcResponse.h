//
//  MHBatchRpcResponse.h
//  MiNetworkFramework
//
//  Created by huchundong on 2017/7/6.
//  Copyright © 2017年 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MHBatchRpcResponse : NSObject
@property(nonatomic, strong)NSArray* result;
@end
