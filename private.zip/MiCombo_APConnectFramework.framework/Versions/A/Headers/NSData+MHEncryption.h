//
//  NSData+MHEncryption.h
//  OpenMiHome
//
//  Created by CoolKernel on 1/17/17.
//  Copyright © 2017 CoolKernel. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (MHEncryption)

- (NSData *)mhEncrytWith:(NSString *)key iv:(NSString *)iv;

- (NSData *)mhDecrptWith:(NSString *)key iv:(NSString *)iv;
@end
