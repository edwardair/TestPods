//
//  MHGetDevPropertyRequest.h
//  MiNetworkFramework
//
//  Created by CoolKernel on 05/07/2017.
//  Copyright © 2017 zhangyinze. All rights reserved.
//

#import "MHMiotBaseRequest.h"

@interface MHGetDevPropertyRequest : MHMiotBaseRequest
@property (nonatomic, strong) NSArray *pids;

@end
