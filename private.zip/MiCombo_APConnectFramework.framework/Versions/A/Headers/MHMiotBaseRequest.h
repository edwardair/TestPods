//
//  MHMiotBaseRequest.h
//  MiNetworkFramework
//
//  Created by CoolKernel on 05/07/2017.
//  Copyright © 2017 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const MIOT_SPEC_HOST;

@interface MHMiotBaseRequest : NSObject

/**
设置spec 请求的版本，默认为 2，可选设置为 1 兼容少量老旧设备

 @param version 1 or 2
 */
@property (nonatomic, assign)NSInteger specVersion; //MIOT Spec 版本号，默认为 2
- (void)setMiotRequestVersion:(NSInteger)version;

- (BOOL)isNormalMiotRequest;

- (NSString *)baseurl;

- (NSString *)path;
/**
 *  一个完整的 URL
 *
 *  @return
 */
- (NSString *)absoluteURL;
/**
 *
 *  @return 每个 request 需要的参数
 */
- (NSDictionary *)requestParameters;


/**
 *  需要再 Head 中设置的参数
 *
 *  @return
 */
- (NSDictionary *)headParameters;

@end
