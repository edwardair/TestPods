//
//  MHXiaoMiBleMeshReportResultRequest.h
//  MiHomeKit
//
//  Created by 彭勇 on 2018/8/24.
//

#import  "MHBaseRequest.h"
@interface MHXiaoMiBleMeshReportResultRequest : MHBaseRequest
@property (nonatomic, copy) NSString *did;
@property (nonatomic, copy) NSString *auth;
@property (nonatomic, copy) NSString *deviceKey;
@property (nonatomic, assign) NSInteger result;

@end
