//
//  MHCDeviceSubscriptions.h
//  MiNetworkFramework
//
//  Created by huchundong on 2017/10/11.
//  Copyright © 2017年 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHMiotBaseRequest.h"
typedef enum MHCDeviceSubscriptionsRequestType{
    MHCDeviceSubscriptionsRequestTypeProperties,
    MHCDeviceSubscriptionsRequestTypeEvent,
    MHCDeviceSubscriptionsRequestTypeDeleteProperties,
}MHCDeviceSubscriptionsRequestType;

@interface MHCDeviceSubscriptionsRequest : MHMiotBaseRequest
@property(nonatomic, assign)MHCDeviceSubscriptionsRequestType requestType;
@property(nonatomic, strong)NSArray* targets;
@property(nonatomic, strong)NSString* authorization;
@property(nonatomic, strong)NSString* identifier;
@end
