//
//  MHGetLatestFirmwareVersionInfoV2Request.h
//  MiHomeKit
//
//  Created by 彭勇 on 2019/2/19.
//

#import "MHBaseRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface MHGetLatestFirmwareVersionInfoV2Request : MHBaseRequest
@property (nonatomic, copy) NSString *model;
@property (nonatomic, copy) NSString *did;
@property (nonatomic, copy) NSString *pluginLevel;
@property (nonatomic, copy) NSString *appVersion;
@end

NS_ASSUME_NONNULL_END
