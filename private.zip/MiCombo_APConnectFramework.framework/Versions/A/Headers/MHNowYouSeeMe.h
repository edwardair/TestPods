//
//  MHNowYouSeeMe.h
//  MiHomeKit
//
//  Created by 彭勇 on 2017/6/28.
//  Copyright © 2017年 小米移动软件. All rights reserved.
//

#ifndef MHNowYouSeeMe_h
#define MHNowYouSeeMe_h

#define mhsecure_save xq34n58

#define mhsecure_withMac n8jj2

#define mhsecure_queryWithMac lo78xqco

#define mhsecure_andCallback qycf428d

#define mhsecure_KeyChainService @"LTMKChainService"

#define mhsecure_DESKey @"894158105aff"

#define mhsecure_deviceId t6rx8d

#define mhsecure_deleteWithMac A8ACBD24E6FF

#define mhsecure_fetchLTMKFromServerByDid A7A7367D4C7

#define mhsecure_aes_key @"7C9BCDFB067643D9891214F9AF735548"

#define mhsecure_aes_iv @"DE26E2D27E7D416FB550E09293F2935A"

#define mhsecure_code_aes @"mhsecure0417"

#define mhmesh_code_aes @"mhmesh1102"

#endif /* MHNowYouSeeMe_h */
