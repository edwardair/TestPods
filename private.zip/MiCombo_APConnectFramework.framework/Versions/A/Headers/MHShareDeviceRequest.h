//
//  MHShareDeviceRequest.h
//  MiDeviceFramework
//
//  Created by yinze zhang on 16/9/9.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@class MHDevice;
@interface MHShareDeviceRequest : MHBaseRequest

-(instancetype)initWithDevices:(NSArray<MHDevice*>*)devices toUserId:(NSString*)userId type:(NSString*)type;

@end
