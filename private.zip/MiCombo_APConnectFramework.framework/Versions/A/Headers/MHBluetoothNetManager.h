//
//  MHBluetoothNetManager.h
//  MiBluetoothFramework
//
//  Created by yinze zhang on 2016/11/21.
//  Copyright © 2016年 yinze zhang. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MHBluetoothManager;

//因为兼容其他app不能使用category,所以包一层
@interface MHBluetoothNetManager : NSObject

@property(nonatomic, strong) MHBluetoothManager* bluetoothManager;


-(void)applyDidWithLoginToken:(NSData*)loginToken optionalOldDid:(NSString* )did result:(void(^)(NSDictionary* data,NSError* error))resultBlock;

-(void)bindDidWithLoginToken:(NSData*)loginToken optionalOldDid:(NSString* )did beaconKey:(NSData*)beaconKey result:(void(^)(NSDictionary* data, NSError* error))resultBlock;

@end
