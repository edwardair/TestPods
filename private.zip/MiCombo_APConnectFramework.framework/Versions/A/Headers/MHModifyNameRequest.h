//
//  MHModifyNameRequest.h
//  MiDeviceFramework
//
//  Created by yinze zhang on 16/9/9.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"
@class MHDevice;

@interface MHModifyNameRequest : MHBaseRequest

-(instancetype)initWithNewName:(NSString*)name oldDevice:(MHDevice*)device;

@end
