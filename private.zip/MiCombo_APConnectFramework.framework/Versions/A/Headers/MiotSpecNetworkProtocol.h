

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger,MiotSpecNetworkMethod) {
    MiotSpecNetworkMethod_GET,
    MiotSpecNetworkMethod_POST,
    MiotSpecNetworkMethod_PUT,
    MiotSpecNetworkMethod_DELETE
};
//
@protocol MiotSpecNetworkProtocol <NSObject>

- (void)RequestCommonURL:(NSString *)url
                method:(MiotSpecNetworkMethod)method
                params:(NSDictionary *)params
               success:(void(^)(id))success
               failure:(void(^)(NSError*))failure;

- (void)sendRequest:(id)request
             method:(MiotSpecNetworkMethod)method
          success:(void(^)(id))success
          failure:(void(^)(NSError*))failure;
@end


