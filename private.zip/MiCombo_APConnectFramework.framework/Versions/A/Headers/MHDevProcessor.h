//
//  MHDevProcessor.h
//  MiNetworkFramework
//
//  Created by CoolKernel on 05/07/2017.
//  Copyright © 2017 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHDeviceProfile.h"
typedef enum MHDevProcessorErrorType{
    kMHCSubscriptionPropertiesNotProperty = -1000, //没有订阅的属性
    kMHCSubscriptionRegIdIsNull = -1001,    //push没有成功
    kMHCSubscriptionauthorizationIsNull = -1002,   //没有传app scret key。
    kMHCSubscriptionSubIdIsNull = -1003,   //属性订阅的subId 为空
    kMHCSubscriptionPropetiesIsNull = -1004, //订阅的属性为空
}MHDevProcessorErrorType;

typedef NS_ENUM(NSInteger,MHDevSpecVersion) {
    MHDevSpecVersionV1 = 1,
    MHDevSpecVersionV2 = 2
};

@class MHGetDevProfileRequest;
@interface MHDevProcessor : NSObject

+ (instancetype)shared;

/**
 设置使用 MIOT Spec 版本，默认为 V2，兼容绝大数设备,可从 https://miot-spec.org/miot-spec-v2/instances?status=all 中查询
 若设备model不在该表中，对该设备的操作请单独设置为 v1 后再调用 MHDevprocessor 下的其他接口。
 @param type
 */
- (void)setDevSpecType:(MHDevSpecVersion)version;

- (void)pullDeviceProfileWithType:(NSString *)type
                       completion:(void (^)(MHDeviceProfile *, NSError *))completion;


- (void)getDeviceList:(void (^)(NSArray <MHMiotDevice *> *, NSError *))completion;


- (void)getDeviceProperties:(NSArray <NSString *> *)pids
                 completion:(void (^)(NSArray <MHDevPropertyValue *> *, NSError *error))completion;

- (void)setDeviceProperties:(NSArray <MHDevPropertyValue *> *)properties
                 completion:(void (^)(MHDevPropertyResponse* response, NSError *error))completion;

- (void)setDeviceAction:(NSString*)aid inParam:(NSArray*)inParam completion:(void (^)(MHDevServiceResponse* response, NSError *error))completion;

- (void)unbindDevice:(NSString*)did success:( void(^)(id obj)) successBlock fail:(void (^)(NSError* err) ) errBlock;


- (void)subscribeProbeperties:(NSArray*) properties withAuthorization:(NSString*)authorization identifier:(NSString*)identifier success:( void(^)(MHCSubscriptionPropertyResponse*  obj)) successBlock fail:(void (^)(NSError* err) ) errBlock;

- (void)unsubscribeProbeperties:(NSArray*) properties  success:( void(^)(MHCSubscriptionPropertyResponse*  obj)) successBlock fail:(void (^)(NSError* err) ) errBlock;
 

- (void)subscriptionEvent:(NSArray*) properties withAuthorization:(NSString*)authorization identifier:(NSString*)identifier success:( void(^)(id obj)) successBlock fail:(void (^)(NSError* err) ) errBlock;
@end
