//
//  MiotSpecActionRequest.h
//  AFNetworking
//
//  Created by pencilCool on 2019/5/8.
//

#import <Foundation/Foundation.h>
#import "MiotSpecBaseRequest.h"
NS_ASSUME_NONNULL_BEGIN

@interface MiotSpecActionRequest : MiotSpecBaseRequest
@property(nonatomic, assign) NSString *aid;
@property(nonatomic, strong) NSArray *inParam;
@end

NS_ASSUME_NONNULL_END
