//
//  MHShareUserRequest.h
//  MiDeviceFramework
//
//  Created by yinze zhang on 2016/11/3.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHShareUserRequest : MHBaseRequest

-(instancetype)initWithPid:(NSString*)pid did:(NSString*)did;

@end
