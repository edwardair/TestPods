//
//  MHComboConnectManager.h
//  MiBluetoothFramework
//
//  Created by yinze zhang on 2016/11/22.
//  Copyright © 2016年 yinze zhang. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MHBluetoothDevice;

//@protocol MHComboQuickConnectStateMachineDelegate <NSObject>
//
//- (void)comboFSM :(MHComboQuickConnectStateMachine *)comboFSM failedSenddingSSIDAndPassword:(kComboQuickConnectyErrorCode)errorcode;
//- (void)comboFSMDidConnectAp:(MHComboQuickConnectStateMachine *)comboFSM;
//- (void)comboFSMDidConnectCloud:(MHComboQuickConnectStateMachine *)comboFSM;
//- (void)comboFSMDidDisconnect:(MHComboQuickConnectStateMachine *)comboFSM;
//@end

typedef NS_ENUM(NSInteger,kComboConnectErrorType){
    comboConnectDeviceError         = 1,
    comboConnectRegisterError       = 2,
    comboConnectError               = 3,
    comboConnectPasswordError       = 4,
    comboConnectBledisconnectError  = 5,
    comboConnectBleWifiError        = 6,
};

typedef NS_ENUM(NSInteger,kComboConnectCountry) {
    comboConnectCountryChina,       //@"cn" 中国大陆
    commboConnectCountrySingapore,  //@"sg"   新加坡
    commboConnectCountryUSA,        //@"us"   美国 (美国服务器)
    commboConnectCountryEurope,     //@"de"   欧洲服务器:德国
    
    commboConnectCountryTaiwan,     //@"tw"  台湾
    commboConnectCountryIndia,      //@"in"   印度(新加坡服务器)
    commboConnectCountryIndia2,     //@"i2"   印度(印度服务器)
    commboConnectCountryRussia,     //@"ru"   俄罗斯
    commboConnectCountryHongkong,   //@"hk"   香港
    commboConnectCountryUS_SG,      //@"us_sg"   美国（新加坡服务器）
    commboConnectCountryTR,         //@"tr"   土耳其
    commboConnectCountryKorea,      //@"kr"   韩国
    commboConnectCountryOthers      //@"others"   其它（新加坡服务器）
};

@interface MHComboConnectManager : NSObject

@property(nonatomic, copy) NSString* uid;
@property(nonatomic, copy) NSString* ssid;
@property(nonatomic, copy) NSString* password;
@property(nonatomic, assign) kComboConnectCountry country;

-(void)comboConnect:(MHBluetoothDevice*)bluetoothDevice success:(void(^)(void))successBlock failure:(void(^)(NSError* error))failureBlock;

@end
