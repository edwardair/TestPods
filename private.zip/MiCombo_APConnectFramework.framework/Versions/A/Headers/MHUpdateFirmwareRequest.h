//
//  MHUpdateFirmwareRequest.h
//  MiDeviceFramework
//
//  Created by yinze zhang on 16/9/9.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHUpdateFirmwareRequest : MHBaseRequest

-(instancetype)initWithDid:(NSString*)did;

@end
