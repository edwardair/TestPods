//
//  MHSharedDevices.h
//  MiDeviceFramework
//
//  Created by yinze zhang on 2016/11/3.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHSharedDevice.h"
@interface MHSharedDevices : NSObject
@property(nonatomic, strong) NSArray<MHSharedDevice*> *sharedDevices;
@end
