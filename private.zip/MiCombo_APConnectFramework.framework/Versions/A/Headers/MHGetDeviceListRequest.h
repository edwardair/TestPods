//
//  MHGetDeviceListRequest.h
//  MiNetworkFramework
//
//  Created by CoolKernel on 06/07/2017.
//  Copyright © 2017 zhangyinze. All rights reserved.
//

#import "MHMiotBaseRequest.h"

@interface MHGetDeviceListRequest : MHMiotBaseRequest


@end
