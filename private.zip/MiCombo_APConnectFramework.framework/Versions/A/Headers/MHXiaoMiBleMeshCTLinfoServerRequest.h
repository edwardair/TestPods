//
//  MHXiaoMiMeshCTLinfoServerRequest.h
//  MiHomeKit
//
//  Created by 彭勇 on 2018/6/6.
//

#import  "MHBaseRequest.h"

@interface MHXiaoMiBleMeshCTLinfoServerRequest : MHBaseRequest

@end
