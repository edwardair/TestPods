//
//  MHReplyShareRequest.h
//  MiDeviceFramework
//
//  Created by yinze zhang on 2016/11/3.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHReplyShareRequest : MHBaseRequest

-(instancetype)initWithmsgId:(NSString*)msgId action:(NSString*)action invId:(NSInteger)invId;

@end
