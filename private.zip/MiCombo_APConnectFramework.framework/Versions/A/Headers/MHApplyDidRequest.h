//
//  MHApplyDidRequest.h
//  MiBluetoothFramework
//
//  Created by yinze zhang on 2016/9/28.
//  Copyright © 2016年 yinze zhang. All rights reserved.
//
#import "MHBaseRequest.h"

@interface MHApplyDidRequest : MHBaseRequest

-(instancetype)initWithDid:(NSString*)did andModel:(NSString*)model andToken:(NSData*)token andMac:(NSString*)mac;

@end
