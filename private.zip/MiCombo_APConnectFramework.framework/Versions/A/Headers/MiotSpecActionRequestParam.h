//
//  MiotSpecActionRequestParam.h
//  Pods
//
//  Created by pencilCool on 2019/5/10.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MiotSpecActionRequestParam : NSObject
@property (nonatomic, assign) NSString *aid;
@property (nonatomic, strong) NSArray *inParam;
@end

NS_ASSUME_NONNULL_END
