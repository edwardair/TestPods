//
//  MHXiaoMiBleMeshLoginFiniteStateMachine.h
//  MiHomeKit
//
//  Created by 彭勇 on 2018/6/25.
//

//#import "MHXiaoMiBleSecureLoginFiniteStateMachine.h"

#import <MJFBluetooth/MHXiaoMiBleLoginFiniteStateMachine.h>

@interface MHXiaoMiBleMeshLoginFiniteStateMachine : MHXiaoMiBleLoginFiniteStateMachine

@end
