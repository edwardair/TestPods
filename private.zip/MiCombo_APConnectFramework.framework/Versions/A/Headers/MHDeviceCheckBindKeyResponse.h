//
//  MHDeviceCheckBindKeyResponse.h
//  Pods
//
//  Created by pencilCool on 2019/5/29.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MHDeviceCheckBindKeyResponse : NSObject
 /**
  0  表示绑定中，客户端继续轮询；
  1  表示绑定成功，
  -1 表示后端内部错误，
  -2 表示绑定已超时，
  -3 表示bindkey不存在，
  客户端给用户提示，不再轮询
  */
@property (nonatomic, assign) NSInteger ret;

/**
 要求客户端在`checkAfterInterval`秒后再来查询，
 如果值为0或者没有这个key，则停止轮询
 */
@property (nonatomic, assign) NSInteger checkAfterInterval;

/**
 bindkey 对应的设备的did
 */
@property (nonatomic, copy) NSString* did;
@end

NS_ASSUME_NONNULL_END
