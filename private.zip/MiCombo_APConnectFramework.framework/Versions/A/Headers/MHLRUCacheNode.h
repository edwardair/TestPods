//
//  MHLRUCacheNode.h
//  LRUCacheDemo
//
//  Created by hanyunhui on 2017/3/17.
//  Copyright © 2017年 hanyunhui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MHLRUCacheNode : NSObject <NSCoding>

@property (nonatomic, strong, readonly) id value;
@property (nonatomic, strong, readonly) id key;
@property (nonatomic, strong) MHLRUCacheNode *next;
@property (nonatomic, strong) MHLRUCacheNode *prev;
//@property (nonatomic, copy) RemovedCallBack removedBlock;

+ (instancetype)nodeWithValue:(id)value key:(id)key;
- (instancetype)initWithValue:(id)value key:(id)key;
//- (void)beRemoved;

@end
