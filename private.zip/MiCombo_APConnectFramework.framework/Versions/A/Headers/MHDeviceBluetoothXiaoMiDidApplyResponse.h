//
//  MHDeviceBluetoothXiaoMiDidApplyResponse.h
//  MiHomeKit
//
//  Created by wangdongsheng on 16/3/7.
//  Copyright © 2016年 小米移动软件. All rights reserved.
//


@interface MHDeviceBluetoothXiaoMiDidApplyResponse : NSObject
@property (nonatomic, assign)NSInteger code;
@property (nonatomic, copy) NSString* message;
@property (nonatomic, copy) NSString *did;

+ (instancetype)responseWithJSONObject:(id)object;
@end
