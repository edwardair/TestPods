//
//  MHDeviceGroupStatusConfigData.h
//  MiHomeDeviceUI
//
//  Created by zhangxu on 2018/9/5.
//


#define Device_Loading @"0"
#define Device_LoadFailed @"3"
#define Device_LoadSuccess @"1"
#import <Foundation/Foundation.h>

@interface MHDeviceGroupStatusConfigData : NSObject

@property (nonatomic, copy) NSString *groupDid;
@property (nonatomic, strong) NSDictionary *memberShip;
@property (nonatomic, copy) NSString *status;

@end
