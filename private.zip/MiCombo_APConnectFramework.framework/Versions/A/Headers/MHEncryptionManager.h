//
//  MHEncryptionManager.h
//  OpenMiHome
//
//  Created by CoolKernel on 1/17/17.
//  Copyright © 2017 CoolKernel. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MHEncryptionManager : NSObject
+ (NSData *)encryptData:(NSData *)data key:(NSString *)key iv:(NSString *)iv;
+ (NSData *)decryptData:(NSData *)data key:(NSString *)key iv:(NSString *)iv;
@end
