//
//  MHFetchTimerListRequest.h
//  MiDeviceFramework
//
//  Created by yinze zhang on 2016/10/20.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHFetchTimerListRequest : MHBaseRequest

@property(nonatomic, copy, readonly) NSString* did;


-(instancetype)initWithDid:(NSString*)did;

@end
