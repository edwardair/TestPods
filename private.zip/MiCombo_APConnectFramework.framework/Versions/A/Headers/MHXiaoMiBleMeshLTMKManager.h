//
//  MHXiaoMiBleMeshLTMKManager.h
//  MiHomeKit
//
//  Created by 彭勇 on 2018/11/2.
//

#import <Foundation/Foundation.h>


@interface MHXiaoMiBleMeshLTMKManager : NSObject

+ (void)saveLTMK:(NSData *)LTMK withDID:(NSString *)did;

+ (void)fetchLTMKWithDID:(NSString *)did andCallback:(void (^)(NSData *))callback;

+ (BOOL)deleteLTMK:(NSString *)did;

@end

