//
//  MiotSpecSubscriptionPropertyResponse.h
//  AFNetworking
//
//  Created by pencilCool on 2019/5/10.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MiotSpecSubscriptionPropertyValue : NSObject
@property (nonatomic, copy) NSString* message;
@property (nonatomic, copy) NSString* pid;
@property (nonatomic, assign) NSInteger status;
@end


@interface MiotSpecSubscriptionPropertyResponse : NSObject
@property (nonatomic, assign)NSInteger expired;
@property (nonatomic, strong)NSArray<MiotSpecSubscriptionPropertyValue*>* properties;
@end

NS_ASSUME_NONNULL_END
