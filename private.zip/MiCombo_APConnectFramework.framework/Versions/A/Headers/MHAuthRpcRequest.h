//
//  MHAuthRpcRequest.h
//  MiNetworkFramework
//
//  Created by CoolKernel on 28/02/2017.
//  Copyright © 2017 zhangyinze. All rights reserved.
//

#import "MHAuthBaseRequest.h"

@interface MHAuthRpcRequest : MHAuthBaseRequest
//设备 id
@property (nonatomic, copy, readonly) NSString *deviceId;

//调用方法
@property (nonatomic, copy, readonly) NSString *method;

//具体参数
@property (nonatomic, strong, readonly) id params;



-(instancetype)initWithDeviceId:(NSString*)deviceId
                         method:(NSString*)method
                         params:(id)params;

@end
