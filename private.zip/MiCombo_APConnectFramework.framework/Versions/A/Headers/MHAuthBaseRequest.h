//
//  MHAuthBaseRequest.h
//  MiNetworkFramework
//
//  Created by CoolKernel on 28/02/2017.
//  Copyright © 2017 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHAuthBaseRequest : MHBaseRequest

@end
