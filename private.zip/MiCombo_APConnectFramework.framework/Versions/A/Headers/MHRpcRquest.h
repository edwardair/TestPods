//
//  MHRpcRquest.h
//  MSmartHomeFramework
//
//  Created by zhangyinze on 16/8/18.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHRpcRquest : MHBaseRequest

//设备 id
@property (nonatomic, copy, readonly) NSString *deviceId;

//调用方法
@property (nonatomic, copy, readonly) NSString *method;

//具体参数
@property (nonatomic, strong, readonly) id params;



-(instancetype)initWithDeviceId:(NSString*)deviceId
                         method:(NSString*)method
                         params:(id)params;



@end
