//
//  MHXiaoMiBleMeshDevInfoRequest.h
//  MiHomeKit
//
//  Created by 彭勇 on 2018/11/2.
//

#import  "MHBaseRequest.h"

@interface MHXiaoMiBleMeshDevInfoRequest : MHBaseRequest

@property (copy, nonatomic) NSString *did;

@end
