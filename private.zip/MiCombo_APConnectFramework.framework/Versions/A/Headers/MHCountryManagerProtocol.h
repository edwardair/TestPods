//
//  MHCountryManagerProtocol.h
//  MiBluetoothDiscoveryFramework
//
//  Created by huchundong on 2018/2/11.
//  Copyright © 2018年 小米软件有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MHCountryManagerProtocol <NSObject>
- (BOOL)isInChinaNow;
- (NSString*)curServerCode;
@end
