//
//  MiotSpecNetworking.h
//  MiHome
//
//  Created by coolkernel on 2018/8/3.
//  Copyright © 2018 小米移动软件. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MiCombo_APConnectFramework/MiotSpecNetworkProtocol.h>

typedef void(^MiotCompletion)(id response, NSError *);

@class MJFBaseRequest;
@interface MiotSpecNetworking : NSObject

@property (nonatomic, strong) id<MiotSpecNetworkProtocol> delegate;

+ (instancetype)shared;

/**
 获取具体设备instance profile
 调用的接口是：
 https://miot-spec.org/miot-spec-v2/instance
 */
- (void)pullDeviceInstanceWithDeviceType:(NSString *)devType
                              completion:(MiotCompletion)completion;

/**
 读取一个DeviceType的具体定义
 调用的接口是：
 https://miot-spec.org/miot-spec-v2/spec/device
 */
- (void)pullDeviceDefineWithDevType:(NSString *)devType
                         completion:(MiotCompletion)completion;

/**
 读取一个ServiceType的具体定义
 调用的接口是：
 https://miot-spec.org/miot-spec-v2/spec/service
 */
- (void)pullServiceDefineWithServiceType:(NSString *)serviceType
                              completion:(MiotCompletion)completion;

/**
 读取一个PropertyType的具体定义
 调用的接口是：
 https://miot-spec.org/miot-spec-v2/spec/property
 */
- (void)pullPropertyDefineWithPropertyType:(NSString *)propertyType
                                completion:(MiotCompletion)completion;

/**
 读取一个ActionType的具体定义
 调用的接口是：
 https://miot-spec.org/miot-spec-v2/spec/action
 */
- (void)pullActionDefineWithActionType:(NSString *)actionType
                            completion:(MiotCompletion)completion;

/**
读取一个EventType的具体定义
调用的接口是：
https://miot-spec.org/miot-spec-v2/spec/event
 */
- (void)pullEventDefineWithEventType:(NSString *)eventType
                          completion:(MiotCompletion)completion;

/**
 获取指定开发模式下所有支持的spec的列表
 调用的接口是：
 https://miot-spec.org/miot-spec-v2/instances
 */
- (void)pullAllSupportMiotspecMapper:(NSString *)status
                          completion:(MiotCompletion)completion;

//获取当前帐号支持spec mapper
- (void)pullUserSupportMiotspecMapper:(MiotCompletion)completion;

- (void)sendRequest:(id)request
         httpMethod:(MiotSpecNetworkMethod)httpMethod
            success:(void(^)(id object))success
            failure:(void(^)(NSError *error))failure;

@end
