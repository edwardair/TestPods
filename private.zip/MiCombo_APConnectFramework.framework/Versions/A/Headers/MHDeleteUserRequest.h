//
//  MHDeleteUserRequest.h
//  MiDeviceFramework
//
//  Created by yinze zhang on 2016/11/3.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@class MHDevice;
@interface MHDeleteUserRequest : MHBaseRequest

-(instancetype)initWithDevice:(MHDevice*)device userList:(NSArray*)userList;

@end
