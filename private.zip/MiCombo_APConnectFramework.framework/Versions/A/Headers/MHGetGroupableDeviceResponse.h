//
//  MHGetGroupableDeviceResponse.h
//  MiHomeDeviceUI
//
//  Created by zhangxu on 2018/8/22.
//

#import <Foundation/Foundation.h>

@interface MHGetGroupableDeviceResponse : NSObject
@property (nonatomic, assign) NSInteger code;
@property (nonatomic, copy  ) NSString *message;
@property (nonatomic, copy  ) NSDictionary *result;
@end
