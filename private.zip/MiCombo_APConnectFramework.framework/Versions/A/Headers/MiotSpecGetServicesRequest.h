//
//  MiotSpecGetServicesRequest.h
//  MiNetworkFramework
//
//  Created by CoolKernel on 2018/3/18.
//  Copyright © 2018 小米移动软件. All rights reserved.
//

#import "MiotSpecBaseRequest.h"

@interface MiotSpecGetServicesRequest : MiotSpecBaseRequest
@property (nonatomic, copy) NSString *type; //读取指定类型的service 列表，例如：switch
@end
