//
//  MHSCTokenResponse.h
//  MiNetworkFramework
//
//  Created by huchundong on 2017/7/5.
//  Copyright © 2017年 zhangyinze. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MHSCTokenResponse : NSObject

@end
