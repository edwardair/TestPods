//
//  MHBTReliableTransmissionManager.h
//  MHMeshOTA
//
//  Created by Shujun on 2018/6/4.
//  Copyright © 2018年 xiaomi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "MHBluetoothDevice.h"
//#import "MHBtDeviceXiaoMi.h"

typedef NS_ENUM(NSInteger, MHBTTransmissionError) {
    MHBTTransmissionErrorPeripheral,  //没找到Peripheral
    MHBTTransmissionErrorCharachter,  //没找到Charachter
    MHBTTransmissionErrorEmptyData,   //没找到数据
    MHBTTransmissionErrorDeviceBusy,  //设备繁忙
    MHBTTransmissionErrorTimeout,     //传输超时
    MHBTTransmissionErrorCancel,      //传输取消
    MHBTTransmissionErrorUnknown      //未知错误
};

@interface MHBTReliableTransmissionManager : NSObject
+ (instancetype)shareInstance;


/**
 蓝牙传输分包协议--可靠传输
 http://wiki.n.miui.com/pages/viewpage.action?pageId=38807741

 @param data 要传输的文件
 @param size 分包后 每一包的大小
 @param iotDevice 设备
 @param dataCharachterUUID 要传送data的特征值
 @param noticeCharachterUUID 接受信息的特征值
 @param timeOut 超时（如果设置为0 则会根据包大小算出一个合理的超时时间）
                杨煜丰说一片大概是100ms 实测大概300ms-400ms 我这里把时间扩大到800ms
 @param progress 进度
 */
- (void)transferData:(NSData *)data
        fragmentSize:(NSInteger)size
           iotDevice:(MHBluetoothDevice *)iotDevice
  dataCharachterUUID:(NSString *)dataCharachterUUID
noticeCharachterUUID:(NSString *)noticeCharachterUUID
             timeOut:(NSTimeInterval)timeOut
            progress:(void(^)(NSInteger progress))progress
             success:(void(^)(void))success
             failure:(void(^)(MHBTTransmissionError errorCode))failure;

- (void)cancelTransfer;

@end
