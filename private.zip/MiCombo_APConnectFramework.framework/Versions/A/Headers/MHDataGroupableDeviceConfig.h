//
//  MHDataGroupableDeviceConfig.h
//  MiHome
//
//  Created by Wayne Qiao on 15/12/3.
//  Copyright © 2015年 小米移动软件. All rights reserved.
//

#import <Foundation/Foundation.h>

//FIXME: 用yymodel 改造
@interface MHDataGroupableDeviceConfig : NSObject

@property (nonatomic, copy) NSString* company;
@property (nonatomic, copy) NSString* name;
@property (nonatomic, copy) NSString* virtualModel;
@property (nonatomic, strong) NSArray* supportModels;

@end
