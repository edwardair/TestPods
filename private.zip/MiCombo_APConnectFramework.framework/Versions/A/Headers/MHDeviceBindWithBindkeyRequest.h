//
//  MHDeviceBindWithBindkeyRequest.h
//  MiNetworkFramework
//
//  Created by huchundong on 2018/3/7.
//  Copyright © 2018年 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHBaseRequest.h"
@interface MHDeviceBindWithBindkeyRequest : MHBaseRequest
@property (nonatomic, copy) NSString* bindkey;
@property (nonatomic, copy) NSString* channel;
@end
