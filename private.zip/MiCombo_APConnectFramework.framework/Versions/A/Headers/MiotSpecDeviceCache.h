//
//  MiotSpecDeviceCache.h
//  AFNetworking
//
//  Created by pencilCool on 2019/5/7.
//

#import "MiotSpecManager.h"
#import "MiotSpecDevice.h"
#import <MiHomeFoundation/MHCacheEngining.h>
#import <MiHomeFoundation/MHDeviceUtil.h>

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MiotSpecDeviceCache : NSObject<MiotSpecCacheProtocol>
+ (instancetype)shared;
@end

NS_ASSUME_NONNULL_END
