//
//  MJFAccountProtocol.h
//  MJFBluetooth
//
//  Created by 张文锋 on 2019/1/2.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol MJFAccountProtocol <NSObject>

@required

-(void)MJFNetwork_setupMiOauth:(NSString *)appId redirectUrl:(NSString *)redirectUrl;

-(BOOL)MJFNetwork_handleOpenUrl:(NSURL *)url;

-(void)MJFNetwork_clearCookie;

-(void)MJFNetwork_doHttpGetWithUrl:(NSString *)url params:(NSDictionary *)params macKey:(NSString *)macKey completeBlock:(void (^)(id _Nonnull, NSError * _Nonnull))block;

-(void)MJFNetwork_applyAuthCodeWithPermissions:(NSArray *)permissions state:(NSString *)state completeBlock:(void (^)(id _Nonnull, NSError * _Nonnull))block;

-(void)MJFNetwork_applyAccessTokenWithPermissions:(NSArray *)permissions state:(NSString *)state completeBlock:(void (^)(id _Nonnull, NSError * _Nonnull))block;

@end

NS_ASSUME_NONNULL_END
