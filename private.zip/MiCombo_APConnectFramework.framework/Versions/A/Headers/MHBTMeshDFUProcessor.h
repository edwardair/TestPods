//
//  MHBTMeshDFUProcessor.h
//  Pods
//
//  Created by pencilCool on 2019/5/31.
//




/// process mesh device firmware ugrade
#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger,MHMeshDFUState) {
    MHMeshDFUCheckConnection,
    MHMeshDFUCheckConnectionFail,
    MHMeshDFUCheckVersion,
    MHMeshDFUCheckVersionFail,
    MHMeshDFUNeedUpdate,
    MHMeshDFUForceUpdate,
    MHMeshDFUDownloadFirmware,
    MHMeshDFUDownloadFail,
    MHMeshDFUTransferFirmware,
    MHMEshDFUTransferSuccess,
    MHMEshDFUTransferFail,
    MHMeshDFUWaitingDeviceReboot,
    MHMeshDFUSwitchFirmwareFail,
    MHMeshDFUSuccess,
    MHMeshDFUFail,
} ;

typedef NS_ENUM(NSUInteger,MHMeshDFUErrorCode) {
    MHMeshDFUEErrorCodeSuccess,
    MHMeshDFUErrorCodeCheckVersionFail,
    MHMeshDFUErrorCodeDownloadFail,
    MHMeshDFUErrorCodeTransferFail,
    MHMeshDFUErrorCodeSwitchFirmwareFail,
    MHMeshDFUErrorCodeDeviceRebootFail,
};

@protocol  MHBTMeshDFUProcessorDelegate <NSObject>
@required
- (void)meshDFUProcessState:(MHMeshDFUState)state;

- (void)meshDFUProcessSendFirewareProgress:(NSInteger)progress;
@end

@class MHBluetoothDevice;
@class MHXiaoMiBluetoothDevice;
NS_ASSUME_NONNULL_BEGIN

@interface MHBTMeshDFUProcessor : NSObject

- (instancetype)initWithMeshDevice:(MHBluetoothDevice *)device;

/**
 mesh device
 */
@property (nonatomic, strong)  MHBluetoothDevice *bluetoothDevice;

/**
 mesh device start firmware ugrade
 */
@property (nonatomic, copy)  NSString *currentVersion;

@property (nonatomic, copy)  NSString *newVersion;

@property (nonatomic, copy) NSString *changeLog;

/**
 Todo:
 1,check device connect state,
 2,get current version of firware
 3,get last available version of firware
 */
- (void)check;

/**
Todo:
1, download fireware
2, send fireware to device
3, replace old fireware
*/
- (void)startUpdate;


/*
 disconnect device
 */
- (void)disconnect;


@property (nonatomic, weak) id<MHBTMeshDFUProcessorDelegate> delegate;
@end

NS_ASSUME_NONNULL_END
