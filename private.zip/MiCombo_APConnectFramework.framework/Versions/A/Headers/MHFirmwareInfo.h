//
//  MHFirmwareInfo.h
//  MiNetworkFramework
//
//  Created by Shujun on 2017/7/17.
//  Copyright © 2017年 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MHFirmwareInfo : NSObject
@property (nonatomic, copy) NSString * version;
@property (nonatomic, copy) NSString * url;
@property (nonatomic, copy) NSString * changeLog;
@property (nonatomic, copy) NSString * md5;
@end
