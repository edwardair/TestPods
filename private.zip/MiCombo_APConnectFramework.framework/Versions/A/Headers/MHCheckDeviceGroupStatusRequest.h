//
//  MHCheckDeviceGroupStatusRequest.h
//  MiHomeDeviceUI
//
//  Created by zhangxu on 2018/8/22.
//

#import "MHBaseRequest.h"

@interface MHCheckDeviceGroupStatusRequest : MHBaseRequest

@property (nonatomic, strong) NSArray *groupDids;

@end
