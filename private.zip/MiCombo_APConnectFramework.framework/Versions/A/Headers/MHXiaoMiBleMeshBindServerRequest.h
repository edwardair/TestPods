//
//  MHXiaoMiBleMeshBindServerRequest.h
//  AFNetworking
//
//  Created by 彭勇 on 2018/4/19.
//

#import  "MHBaseRequest.h"

@interface MHXiaoMiBleMeshBindServerRequest : MHBaseRequest
@property (nonatomic, assign) NSInteger pdid;
@property (nonatomic, copy) NSString *mac;
@property (nonatomic, copy) NSString *sign;
@property (nonatomic, copy) NSString *did;
@property (nonatomic, copy) NSString *token;
@end
