//
//  MiotSpecService.h
//  AFNetworking
//
//  Created by pencilCool on 2019/5/10.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@class MiotSpecDevice;
@class MiotSpecProperty;
@class MiotSpecAction;
@class MiotSpecEvent;

@interface MiotSpecService : NSObject <NSCoding>
@property (nonatomic, assign) NSInteger siid;        //实例ID （iid）
@property (nonatomic, copy) NSString *type;         //service type
@property (nonatomic, copy) NSString *serviceDes;   //service description (description)
@property (nonatomic, strong) NSArray <MiotSpecProperty *> *properties;
@property (nonatomic, strong) NSArray <MiotSpecAction *> *actions;
@property (nonatomic, strong) NSArray <MiotSpecEvent *> *events;
@property (nonatomic, weak)  MiotSpecDevice *device;

- (MiotSpecProperty *)getPropertyFromPid:(NSInteger)pid;
- (MiotSpecAction *)getActionFromPid:(NSInteger)aid;
- (MiotSpecEvent *)getEventFromPid:(NSInteger)eid;

- (void)assignSubLayer;
@end


NS_ASSUME_NONNULL_END
