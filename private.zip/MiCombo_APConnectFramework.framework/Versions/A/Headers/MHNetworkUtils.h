//
//  MHNetworkUtils.h
//  QuickCnntDemo
//
//  Created by Woody on 14-9-24.
//  Copyright (c) 2014年 Woody. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SystemConfiguration/CaptiveNetwork.h>

@interface MHNetworkUtils : NSObject

+ (MHNetworkUtils* )shareInstance;

+ (NSDictionary*)fetchSSIDInfo;
+ (NSString*)fetchSSID;
+ (NSString*)fetchBSSID;

+ (NSString*)whatismyipdotcom;
+ (NSString*)localWiFiIPAddress;
+ (NSString*)localWiFiBroadcastIPAddress;

/**
 *  @brief 获取ap模式下的设备ip
 */
+ (NSString *)getDeviceIP;

- (void)openSystemSettingPage;

#ifdef APP_DEVELOPMENT
+ (BOOL)LocalDevFlag; //本地DEV标志位
+ (void)setLocalDevFlag:(BOOL)flag; //设置本地DEV标志位
#endif

+ (NSString *)macStringFromData:(NSData *)data;
+ (NSData *)macDataFromString:(NSString *)macString;
+ (NSString *)systemLanguage;

/* 二维码扫描时生成二维码的字符串
 *  @param bindkey       从服务端取到的bindkey
 *  @param wifissid      wifi的 ssid
 *  @param pwd           wifi的密码
 *  @param model         设备model
 *  @param domain        用户所在的国家区域 : 中国 cn 新加坡 sg 美国 us us_sg 欧洲 de 台湾 tw 印度 in i2 俄罗斯 ru 香港 hk 土耳其 tr 韩国 kr 其他others （us_sg,i2,others都是新加坡服务器）
 */
+ (NSString *)encryptedStringForQRCodingWithBindKey:(NSString*)bindkey ssid:(NSString*)wifissid pwd:(NSString*)wifipwd model:(NSString*)model domain:(NSString *)domain;

@end
