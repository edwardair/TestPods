//
//  MiotIotSubscribeRequest.h
//  MiHome
//
//  Created by CoolKernel on 2018/3/18.
//  Copyright © 2018 小米移动软件. All rights reserved.
//

#import "MiotSpecBaseRequest.h"

typedef NS_ENUM(NSInteger,MiotSpecSubscribeType) {
    MiotSpecSubscribeType_EventSub,
    MiotSpecSubscribeType_EventUnSub,
    MiotSpecSubscribeType_PropsSub,
    MiotSpecSubscribeType_PropsUnSub
};

@interface MiotSpecSubscribeRequest : MiotSpecBaseRequest
@property (nonatomic, strong) NSArray *properties;  //[pid]
@property (nonatomic, strong) NSArray *events;      //[eid]
@property (nonatomic, strong) NSDictionary *receiver;
@property (nonatomic, assign) MiotSpecSubscribeType subscribeType;
//  mi push 中的RegId
@property (nonatomic, strong) NSString *pushId;
@end
