//
//  MHSCView.h
//  CMSDKDemoDebug
//
//  Created by huchundong on 2017/7/6.
//  Copyright © 2017年 huchundong. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^MHSCViewCallBack)(id obj);
@interface MHSCView : UIView

@property(nonatomic, copy)MHSCViewCallBack callback;

- (instancetype)initWithFrame:(CGRect)frame
          telecomOperatorName:(NSString *)name
       telecomOperatorAppName:(NSString *)appName;

- (NSString*)sdkVersion;

@end
