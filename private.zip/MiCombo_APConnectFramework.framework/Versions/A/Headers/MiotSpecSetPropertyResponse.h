//
//  MiotSpecSetPropertyResponse.h
//  AFNetworking
//
//  Created by pencilCool on 2019/5/10.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
// 设置属性
@interface MiotSpecSetPropertyResponseValue : NSObject
@property (nonatomic, strong) NSString* pid;
@property (nonatomic, assign) NSInteger status;
@end

@interface MiotSpecSetPropertyResponse:NSObject
@property (nonatomic, strong) NSString *oid;
@property (nonatomic, strong) NSArray<MiotSpecSetPropertyResponseValue*>* properties;
@end

NS_ASSUME_NONNULL_END
