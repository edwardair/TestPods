//
//  MiotSpecSetPropertyRequestParam.h
//  AFNetworking
//
//  Created by pencilCool on 2019/5/10.
//

#import <Foundation/Foundation.h>

@interface MiotSpecSetPropertyRequestParam:NSObject
@property (nonatomic, strong) NSString *pid;
@property (nonatomic, strong) id value;
@end

