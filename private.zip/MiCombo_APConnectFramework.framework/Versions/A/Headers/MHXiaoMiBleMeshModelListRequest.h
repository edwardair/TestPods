//
//  MHXiaoMiBleMeshModelListRequest.h
//  MiHomeKit
//
//  Created by 彭勇 on 2018/6/13.
//

#import  "MHBaseRequest.h"
@interface MHXiaoMiBleMeshModelListRequest : MHBaseRequest
@property (nonatomic, assign) NSInteger pdid;
@end
