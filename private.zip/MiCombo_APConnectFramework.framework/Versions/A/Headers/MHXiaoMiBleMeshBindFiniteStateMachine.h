//
//  MHXiaoMiBleMeshBindFiniteStateMachine.h
//  AFNetworking
//
//  Created by 彭勇 on 2018/4/24.
//
#import <MJFBluetooth/MHXiaoMiBleBindFiniteStateMachine.h>

@interface MHXiaoMiBleMeshBindFiniteStateMachine : MHXiaoMiBleBindFiniteStateMachine

@end
