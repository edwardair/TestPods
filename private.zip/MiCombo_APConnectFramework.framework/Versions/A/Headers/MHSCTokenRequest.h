//
//  MHXCTokenRequest.h
//  MiNetworkFramework
//
//  Created by huchundong on 2017/7/5.
//  Copyright © 2017年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHSCTokenRequest : MHBaseRequest

@end
