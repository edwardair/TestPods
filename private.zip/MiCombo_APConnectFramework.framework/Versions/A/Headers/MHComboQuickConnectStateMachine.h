//
//  MHComboFiniteStateMachine.h
//  MiHome
//
//  Created by wangdongsheng on 16/8/16.
//  Copyright © 2016年 小米移动软件. All rights reserved.
//

#import <MJFBluetooth/MHFiniteStateMachine.h>

@interface MHComboQuickConnectStateMachine : MHFiniteStateMachine
@property (nonatomic, strong) BtCallbackBlock resultCallback;
@property (nonatomic, strong) BtTimeoutBlock timeoutBlock;
@property (nonatomic, strong) BtCancelBlock cancelBlock;
@property (nonatomic, assign) NSTimeInterval timeoutInterval;

- (void)cancelSenddingSSISAndPassword;
@end


