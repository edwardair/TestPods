//
//  MiotDeviceKitManager.h
//  AFNetworking
//
//  Created by pencilCool on 2019/5/7.
//

/*
小米iOT控制端API文档地址：
 https://iot.mi.com/new/guide.html?file=07-%E4%BA%91%E5%AF%B9%E4%BA%91%E5%BC%80%E5%8F%91%E6%8C%87%E5%8D%97/02-%E5%BA%94%E7%94%A8%E4%BA%91%E5%AF%B9%E4%BA%91%E6%8E%A5%E5%85%A5/02-%E5%B0%8F%E7%B1%B3IOT%E6%8E%A7%E5%88%B6%E7%AB%AFAPI#/
 小米iOT协议规范文档：
 https://iot.mi.com/new/guide.html?file=07-%E4%BA%91%E5%AF%B9%E4%BA%91%E5%BC%80%E5%8F%91%E6%8C%87%E5%8D%97/02-%E5%BA%94%E7%94%A8%E4%BA%91%E5%AF%B9%E4%BA%91%E6%8E%A5%E5%85%A5/01-%E5%B0%8F%E7%B1%B3IOT%E5%8D%8F%E8%AE%AE%E8%A7%84%E8%8C%83

*/


#import <Foundation/Foundation.h>
@class MiotSpecDeviceSummary;
@class MiotSpecPropertyValue;
@class MiotSpecGetPropertyResponse;
@class MiotSpecSetPropertyResponse;
@class MiotSpecActionRequestParam;
@class MiotSpecSetPropertyRequestParam;
@class MiotSpecAction;
@class MiotSpecActionResponse;
@class MiotSpecDevice;
@class MiotSpecSubscriptionPropertyResponse;
@class MiotSpecUnsubscriptionPropertyResponse;

NS_ASSUME_NONNULL_BEGIN
@interface MiotSpecDeviceManager : NSObject

+ (instancetype)shared;

/**
 读取物理设备列表
 调用的接口是:
 https://api.home.mi.com/api/v1/devices
 */
- (void)getSpecDeviceSummaryList:(void (^)(NSArray<MiotSpecDeviceSummary *> *list,NSError * error))complete;

/**
 根据物理设备列表中的的设备类型，查询设备支持的spec属性（service，property，event）
 - (void)discoverDevicesServices:(NSArray<MiotSpecDeviceSummary *> *)summaryDevices
 completion:(void (^)(NSArray <MiotSpecDevice *> *deviceInstances, NSError *error))completion;
 */


/**
根据物理设备的设备类型，查询spec定义，生成的spec device 的 instance（service，property，event）
定义见：小米iOT协议规范文档
调用的接口是：
http://miot-spec.org/miot-spec-v2/instance?type=xxxxx
 */
- (void)discoverDeviceServices:(MiotSpecDeviceSummary *)summaryDevice
                    completion:(void (^)(MiotSpecDevice *deviceInstances))completion;

/**
 批量获取属性
 @param pids 属性列表
 @param completion 执行结果。
 
 调用的接口是:
  https://api.home.mi.com/api/v1/properties
 属性的定义见：
 */
- (void)getDeviceProperties:(NSArray <NSString *> *)pids
                 completion:(void (^)(MiotSpecGetPropertyResponse *res, NSError *error))completion;

/**
 设置属性，支持一次性设置多个属性
 
 @param properties 属性的列表
 @param completion 执行结果
 调用的接口是：
  https://api.home.mi.com/api/v1/properties
 */
- (void)setDeviceProperties:(NSArray <MiotSpecSetPropertyRequestParam *> *)properties
                 completion:(void (^)(MiotSpecSetPropertyResponse *res, NSError *error))completion;

/**
调用设备的方法，调用一次只能执行一个方法。
 @param action 方法的定义，包含
 @param completion 执行结果
 调用的接口是：
 https://api.home.mi.com/api/v1/action
 */
- (void)invokeDeviceAction:(MiotSpecActionRequestParam *)action
                completion:(void (^)(MiotSpecActionResponse *res, NSError *error))completion;

/**
 订阅设备属性
 调用的接口是：
 https://api.home.mi.com/api/v1/subscriptions
 POST
 */
- (void)subscribeProperties:(NSArray*) properties
                completion:(void (^)(MiotSpecSubscriptionPropertyResponse *res, NSError *error))completion;

/**
 取消订阅属性
 调用的接口是：
 https://api.home.mi.com/api/v1/subscriptions
 DELETE
 */
- (void)unsubscribeProperties:(NSArray*) properties
                  completion:(void (^)(MiotSpecUnsubscriptionPropertyResponse *res, NSError *error))completion;
@end

NS_ASSUME_NONNULL_END
