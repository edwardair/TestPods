//
//  MHXiaoMiBleMeshRegisterFiniteStateMachine.h
//  MiHomeKit
//
//  Created by 彭勇 on 2018/4/13.
//

#import <MJFBluetooth/MHXiaoMiBleRegisterFiniteStateMachine.h>

@interface MHXiaoMiBleMeshRegisterFiniteStateMachine : MHXiaoMiBleRegisterFiniteStateMachine

@end
