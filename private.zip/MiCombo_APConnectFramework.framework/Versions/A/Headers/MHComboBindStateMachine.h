//
//  MHComboBindStateMachine.h
//  MiHomeKit
//
//  Created by huchundong on 2018/4/23.
//

#import <Foundation/Foundation.h>
#import <MJFBluetooth/MHFiniteStateMachine.h>
#import <MJFBluetooth/MHBtMessageDispatch.h>

@interface MHComboBindStateMachine : MHFiniteStateMachine<CBPeripheralDelegate,CBCentralManagerDelegate>
@property (nonatomic, strong) BtCallbackBlock resultCallback;
@property (nonatomic, strong) BtTimeoutBlock timeoutBlock;
@property (nonatomic, strong) BtCancelBlock cancelBlock;
@property (nonatomic, strong) BtCallbackBlock cloudConnectedBlock;
@property (nonatomic, assign) NSTimeInterval timeoutInterval;
- (void)cancelSenddingSSISAndPassword;
@end



