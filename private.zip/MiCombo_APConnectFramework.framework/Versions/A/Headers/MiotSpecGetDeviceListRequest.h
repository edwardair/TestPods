//
//  MiotSpecGetDeviceListRequest.h
//  MiNetworkFramework
//
//  Created by CoolKernel on 06/07/2017.
//  Copyright © 2018 小米移动软件. All rights reserved.
//

#import "MiotSpecBaseRequest.h"

@interface MiotSpecGetDeviceListRequest : MiotSpecBaseRequest
@property (nonatomic, assign) BOOL compact; //如果只想读区简单信息的话，设置为YES
@property (nonatomic, strong) NSArray *values;//如果希望读取设备列表时，尽可能返回设备的属性值

@end
