//
//  MHBatchRpcRequest.h
//  MiNetworkFramework
//
//  Created by huchundong on 2017/7/6.
//  Copyright © 2017年 zhangyinze. All rights reserved.
//

#import "MHBaseRequest.h"

@interface MHBatchRpcRequest : MHBaseRequest
@property(nonatomic, strong)NSString* method;
@property(nonatomic, strong)NSArray* rpcs;
@end
