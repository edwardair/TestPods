//
//  MHGetGroupableDeviceRequest.h
//  MiHomeDeviceUI
//
//  Created by zhangxu on 2018/8/22.
//

#import "MHBaseRequest.h"

@interface MHGetGroupableDeviceRequest : MHBaseRequest

@end
