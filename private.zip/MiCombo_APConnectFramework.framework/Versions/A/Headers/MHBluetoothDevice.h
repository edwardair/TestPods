//
//  MHBluetoothDevice.h
//  MiBluetoothFramework
//
//  Created by yinze zhang on 16/9/20.
//  Copyright © 2016年 yinze zhang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "MHDevice.h"

@interface MHBluetoothDevice : MHDevice

@property(nonatomic, weak) CBCentralManager* centralManager;
@property(nonatomic, strong) CBPeripheral* peripheral;
@property(nonatomic, strong) NSNumber* RSSI;
@property(nonatomic, assign) BOOL isRegistering;
//@property(nonatomic, strong) NSDictionary* extra;

- (NSData*)bleLoginToken;
- (void)setBleLoginToken:(NSData*)data;
- (void)removeBleLoginToken;


- (BOOL)isSupportStandardAuth;
// 是否是支持蓝牙mesh
- (BOOL)isSupportMiBleMesh;

// 用来判断是否可以连接。
// 比如mesh 设备，它即使连接了，还是能发广播包。
// by pencilCool
- (BOOL)isDeviceConnectable;
@end
