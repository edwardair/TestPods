//
//  MiotSpecGetPropertyResponse.h
//  AFNetworking
//
//  Created by pencilCool on 2019/5/10.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
// 获取属性
@interface MiotSpecGetPropertyResponseValue : NSObject
@property (nonatomic, copy) NSString *pid;
@property (nonatomic, strong) id value;
@property (nonatomic, assign) NSInteger status;
@property (nonatomic, copy) NSString *des;
@end

@interface MiotSpecGetPropertyResponse : NSObject
@property (nonatomic, strong) NSArray<MiotSpecGetPropertyResponseValue*>* properties;
@end



NS_ASSUME_NONNULL_END
