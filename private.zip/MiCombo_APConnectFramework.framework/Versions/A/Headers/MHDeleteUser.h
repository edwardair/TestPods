//
//  MHDeleteUser.h
//  MiDeviceFramework
//
//  Created by yinze zhang on 2016/11/3.
//  Copyright © 2016年 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MHDeleteUser : NSObject

@property (nonatomic, assign) NSInteger pid;
@property (nonatomic, copy) NSString* did;
@property (nonatomic, assign) NSInteger ret;

@end
