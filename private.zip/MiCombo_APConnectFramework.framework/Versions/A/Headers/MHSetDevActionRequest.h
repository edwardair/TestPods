//
//  MHSetDevActionRequest.h
//  MiNetworkFramework
//
//  Created by huchundong on 2017/9/12.
//  Copyright © 2017年 zhangyinze. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHMiotBaseRequest.h"

@class MHDevAction;
@interface MHSetDevActionRequest : MHMiotBaseRequest
@property(nonatomic, strong)NSString*   aid;
@property(nonatomic, strong)NSArray*    inParam;
@end
