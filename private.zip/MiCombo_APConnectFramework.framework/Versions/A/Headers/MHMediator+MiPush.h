//
//  MHMediator+MiPush.h
//  AFNetworking
//
//  Created by pencilCool on 2019/9/17.
//

#import <MiHomeMediator/MHMediator.h>

NS_ASSUME_NONNULL_BEGIN

@interface MHMediator (MiPush)
- (NSString *)MiPush_getRegId;
@end

NS_ASSUME_NONNULL_END
