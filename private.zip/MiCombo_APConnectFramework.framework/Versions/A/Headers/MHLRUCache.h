//
//  MHLRUCache.h
//  LRUCacheDemo
//
//  Created by hanyunhui on 2017/3/17.
//  Copyright © 2017年 hanyunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHLRUCacheNode.h"

typedef void (^RemovedCallBack)(id obj);

@interface MHLRUCache : NSObject <NSCoding>

@property (nonatomic, copy) RemovedCallBack removedCallBack;

- (instancetype)initWithMaxCount:(NSUInteger)maxCount;

- (void)setObject:(id)object forKey:(id)key;
- (void)setObject:(id)object forKey:(id)key removedCallBack:(RemovedCallBack)removedCallBack;
- (id)objectForKey:(id)key;
// 删除指定的节点
- (void)removeNodeForKey:(id)key;
// 清除缓存
- (void)clearAll;
// 打印所有的Cache
- (void)logRootNode;

//将 lru 这个表存到硬盘中
- (void)saveLruCacheToDiskWithPath:(NSString *)path;
//将 lruCache通过硬盘中存储的数据初始化 并为cache添加 removeCallBack
+ (instancetype)loadLruWithPath:(NSString *)path removeCallBack:(RemovedCallBack)removedCallBack;
@end
