//
//  MHBatchDeleteShareRequest.h
//  MiHomeKit
//
//  Created by hanyunhui on 16/8/19.
//  Copyright © 2016年 小米移动软件. All rights reserved.
//

#import "MHBaseRequest.h"

@interface DeleteSharedDeviceInfo:NSObject
@property (nonatomic, copy) NSString *msgId;
@property (nonatomic, copy) NSString *did;
@end


@interface MHDeleteSharedDevicesRequest : MHBaseRequest
- (instancetype)initWithDeviceInfoList:(NSArray <DeleteSharedDeviceInfo *>*)list;
@end
