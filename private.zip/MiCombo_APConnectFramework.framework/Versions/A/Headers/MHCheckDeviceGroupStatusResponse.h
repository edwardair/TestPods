//
//  MHCheckDeviceGroupStatusResponse.h
//  MiHomeDeviceUI
//
//  Created by zhangxu on 2018/8/22.
//

#import "MHDeviceGroupStatusConfigData.h"

@interface MHCheckDeviceGroupStatusResponse : NSObject
@property (nonatomic, assign) NSInteger code;
@property (nonatomic, copy  ) NSString *message;
@property (nonatomic, strong)NSArray<MHDeviceGroupStatusConfigData *> *result;

@end
